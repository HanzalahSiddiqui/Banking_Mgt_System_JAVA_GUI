public class Account extends Customer {
    private int balance;
    private int accountNumber;

    public Account(String fName, String lName, int accNumber, double initialBalance) {
                setFirstName(fName);
            setLastName(lName);
                    this.accountNumber = accNumber;
        this.balance = (int) initialBalance;
    }

    public int getBalance() {
        return balance;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void deposit(int amount) {
        balance += amount;
    }

    public void withdraw(int amount) {
        balance -= amount;
    }

    @Override
    public String toString() {
        return "Account Number: " + accountNumber + ", Holder: " + getFirstName() + " " + getLastName() + ", Balance: " + balance;
    }
}
