public class Customer {
    private String firstName;
     private String lastName;

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

       public void setFirstName(String fName) {
        this.firstName = fName;
    }

        public void setLastName(String lName) {
        this.lastName = lName;
    }
}
