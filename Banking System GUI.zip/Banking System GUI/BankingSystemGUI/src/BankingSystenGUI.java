import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.LinkedList;
import  java.util.*;

public class BankingSystenGUI extends JFrame {
    private LinkedList<Account> globalAccounts;

    private JTextArea accountDetailsArea;
    private JButton showAllButton;
    private JButton depositButton;
    private JButton withdrawButton;
    private JButton transferButton;
    private JTextField accDeposit;
    private JTextField accWithdraw;
    private JTextField acc1Transfer;
    private JTextField acc2Transfer;
    private JTextField depositInput;
    private JTextField withdrawInput;
    private JTextField transferAmount;



    public BankingSystenGUI(LinkedList<Account> accounts) {
            super("Banking System");
                setLayout(null);
        globalAccounts = accounts;


               accountDetailsArea = new JTextArea();
            accountDetailsArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(accountDetailsArea);
            scrollPane.setBounds(10, 10, 580, 200);


            showAllButton = new JButton("Show All");
        showAllButton.setBounds(10, 220, 150, 30);
            depositButton = new JButton("Deposit");
         depositButton.setBounds(10, 260, 150, 30);
            withdrawButton = new JButton("Withdraw");
         withdrawButton.setBounds(10, 300, 150, 30);
                transferButton = new JButton("Transfer");
            transferButton.setBounds(10, 340, 150, 30);


            accDeposit = new JTextField("Enter account number for deposit");
                accDeposit.setBounds(180, 260, 200, 30);
            accWithdraw = new JTextField("Enter account number for withdraw");
            accWithdraw.setBounds(180, 300, 200, 30);
        acc1Transfer = new JTextField("Account number to transfer from");
        acc1Transfer.setBounds(180, 340, 200, 30);
        acc2Transfer = new JTextField("Account number to transfer to");
        acc2Transfer.setBounds(180, 380, 200, 30);
        depositInput = new JTextField("Enter deposit amount");
        depositInput.setBounds(390, 260, 150, 30);
        withdrawInput = new JTextField("Enter withdraw amount");
        withdrawInput.setBounds(390, 300, 150, 30);
        transferAmount = new JTextField("Enter transfer amount");
        transferAmount.setBounds(390, 340, 150, 30);


        add(scrollPane);
        add(showAllButton);
        add(depositButton);
        add(withdrawButton);
        add(transferButton);
        add(accDeposit);
        add(accWithdraw);
        add(acc1Transfer);
        add(acc2Transfer);
        add(depositInput);
        add(withdrawInput);
        add(transferAmount);


        HandlerClass handler = new HandlerClass();

          showAllButton.addActionListener(handler);
                depositButton.addActionListener(handler);
        withdrawButton.addActionListener(handler);
        transferButton.addActionListener(handler);
    }

    private class HandlerClass implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
                if (e.getSource() == showAllButton) {
                    displayAccountDetails();
                        displayCSVData();
            }
                    else if (e.getSource() == depositButton) {
                handleDeposit();
            }           else if (e.getSource() == withdrawButton) {
                handleWithdraw();
                        displayCSVData();
            }       else if (e.getSource() == transferButton) {
                            handleTransfer();
                displayCSVData();
            }
        }


        private void displayAccountDetails() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < globalAccounts.size(); i++) {
                   sb.append(globalAccounts.get(i).toString()).append("\n");
            }
                accountDetailsArea.setText(sb.toString());
        }

        private void displayCSVData() {
            StringBuilder csvData = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new FileReader("Accounts.csv"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    csvData.append(line).append("\n");
                }
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Failed to read CSV file!", "Error", JOptionPane.ERROR_MESSAGE);
            }

            accountDetailsArea.append("\n\nCSV Data:\n" + csvData.toString());
        }

        private void handleDeposit() {
                    int accNumber = Integer.parseInt(accDeposit.getText());
                double amount = Double.parseDouble(depositInput.getText());
                    for (Account account : globalAccounts) {
                        if (account.getAccountNumber() == accNumber) {
                            account.deposit((int) amount);
                    updateCSVFile();
                        displayAccountDetails();
                    return;
                }
            }
            JOptionPane.showMessageDialog(null, "Account not found!", "Error", JOptionPane.ERROR_MESSAGE);
        }


        private void handleWithdraw() {
                int accNumber = Integer.parseInt(accWithdraw.getText());
                    double amount = Double.parseDouble(withdrawInput.getText());
            for (Account account : globalAccounts) {
                 if (account.getAccountNumber() == accNumber) {
                        account.withdraw((int) amount);
                            updateCSVFile();
                    displayAccountDetails();
                    return;
                }
            }
            JOptionPane.showMessageDialog(null, "Account not found!", "Error", JOptionPane.ERROR_MESSAGE);
        }


        private void handleTransfer() {
            int acc1 = Integer.parseInt(acc1Transfer.getText());
            int acc2 = Integer.parseInt(acc2Transfer.getText());
                  double amount = Double.parseDouble(transferAmount.getText());

                Account source = null;
            Account destination = null;


            for (Account account : globalAccounts) {
                     if (account.getAccountNumber() == acc1) {
                    source = account;
                }
                        if (account.getAccountNumber() == acc2) {
                    destination = account;
                }
            }


              if (source != null && destination != null) {
                    Transaction transaction = new Transaction();
                    transaction.transfer(source, destination, (int) amount);
                updateCSVFile();
                displayAccountDetails();
            } else {
                JOptionPane.showMessageDialog(null, "One or both accounts not found!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

    }

    private void updateCSVFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("Accounts.csv"))) {
                    writer.write("First Name,Last Name,Account Number,Balance\n");
                    for (Account account : globalAccounts) {
                writer.write(account.getFirstName() + "," + account.getLastName() + "," +
                         account.getAccountNumber() + "," + account.getBalance() + "\n");
            }
        } catch (IOException e) {
                    e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to update CSV file!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }



}
