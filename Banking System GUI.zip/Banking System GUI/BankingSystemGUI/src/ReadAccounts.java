import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class ReadAccounts {
    private String URL;

    public ReadAccounts(String URL) {
        this.URL = URL;
    }

    public List<Account> getAccounts() throws IOException {
        List<Account> accounts = new LinkedList<>();
        BufferedReader br = new BufferedReader(new FileReader(URL));
        String line;
        br.readLine();
             while ((line = br.readLine()) != null) {
            String[] data = line.split(",");
                    String firstName = data[0];
                        String lastName = data[1];
            int accountNumber = Integer.parseInt(data[2]);
                double balance = Double.parseDouble(data[3]);
            Account account = new Account(firstName, lastName, accountNumber, balance);
                accounts.add(account);
        }
            br.close();
        return accounts;
    }
}
