import javax.swing.*;
import java.io.IOException;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        String file = "Accounts.csv";
             ReadAccounts readAccounts = new ReadAccounts(file);

        try {
                LinkedList<Account> accounts = new LinkedList<>();
                    accounts.addAll(readAccounts.getAccounts());

              accounts.add(new Account("John", "Doe", 101, 5000));
                    accounts.add(new Account("Jane", "Smith", 102, 10000));
                accounts.add(new Account("Alice", "Johnson", 103, 7500));

            BankingSystenGUI gui = new BankingSystenGUI(accounts);
            gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


                gui.setSize(1000, 1000);
            gui.setVisible(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
